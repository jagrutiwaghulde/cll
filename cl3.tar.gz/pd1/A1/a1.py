import unittest

class TestThis(unittest.TestCase):
	def test1(self):
		self.assertEqual(func("input.txt",3),True)
	def test2(self):
		self.assertEqual(func("lolthisisnotafilenoob.txt",-999),False)


class Search:
	arr=[]
	def __init__(self,a):
		self.arr=a

	def Partition(self,p,q):
		pivot=self.arr[p]
		i=p
		for j in range(p+1,q+1):
			if(self.arr[j]<pivot):
				i+=1
				temp=self.arr[i]
				self.arr[i]=self.arr[j]
				self.arr[j]=temp
		temp=self.arr[i]
		self.arr[i]=self.arr[p]
		self.arr[p]=temp	
		return i
	
	def QuickSort(self,p,q):
		if(p<q):
			r=self.Partition(p,q)
			self.QuickSort(p,r-1)
			self.QuickSort(r+1,q)
		return self.arr
	
	def BinarySearch(self,num,low,high):
		if(low<high):
			mid=low+(high-low)/2
			if(num==self.arr[mid]):
				return mid
			elif (num<self.arr[mid]):
				return self.BinarySearch(num,low,mid)
			else:
				return self.BinarySearch(num,mid+1,high)
		else:
			return -1


def func(filename,num):
	a=[]
	try:
		with open(filename,'r') as f:
			for line in f:
				a.append(int(line))
		f.close()
		obj = Search(a)
		print obj.QuickSort(0,len(a)-1)
		ind=obj.BinarySearch(num,0,len(a))
		if(ind+1):
			print "Number found at position",ind
			return True
		else:
			print "Number not found"

	except Exception as e:
		print "ERROR BRUH"
	
	return False

if __name__=='__main__':
	filename=raw_input("Enter Filename:")
	num=input("Enter element to be searched:")
	func(filename,num)

print "----------------------------------------------------------------------"
print "TEST CASES"
unittest.main()
