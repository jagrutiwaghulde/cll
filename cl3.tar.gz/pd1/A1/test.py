import unittest

class TestThis(unittest.TestCase):
	def test1(self):
		self.assertEqual(func("input.txt",3),True)
	def test2(self):
		self.assertEqual(func("lolthisisnotafilenoob.txt",-999),False)


class Search:
	arr=[]
	def __init__(self,a):
		self.arr=a

	def sort_list(self):
		for k in range(len(self.a)-1,0,-1):
			for i in range(k):
				if(self.a[i]>self.a[i+1]):
					self.a[i+1],self.a[i]=self.a[i],self.a[i+1]
		print("sorted array is:")
		return self.a

	def BinarySearch(self,num,low,high):
		if(low<high):
			mid=low+(high-low)/2
			if(num==self.arr[mid]):
				return mid
			elif (num<self.arr[mid]):
				return self.BinarySearch(num,low,mid)
			else:
				return self.BinarySearch(num,mid+1,high)
		else:
			return -1


def func(filename,num):
	a=[]
	try:
		with open(filename,'r') as f:
			for line in f:
				a.append(int(line))
		f.close()
		obj = Search(a)
		print obj.sort_list(a)
		ind=obj.BinarySearch(num,0,len(a))
		if(ind+1):
			print "Number found at position",ind
			return True
		else:
			print "Number not found"

	except Exception as e:
		print "ERROR BRUH"
	
	return False

if __name__=='__main__':
	filename=raw_input("Enter Filename:")
	num=input("Enter element to be searched:")
	func(filename,num)

print "----------------------------------------------------------------------"
print "TEST CASES"
unittest.main()
