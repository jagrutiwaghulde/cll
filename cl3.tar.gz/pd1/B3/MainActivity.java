package com.example.akshay.rishabh;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import net.objecthunter.exp4j.Expression;
import net.objecthunter.exp4j.ExpressionBuilder;

public class MainActivity extends AppCompatActivity {
    private Button mOne;
    private Button mTwo;
    private Button mThree;
    private Button mFour;
    private Button mFive;
    private Button mSix;
    private Button mSeven;
    private Button mEight;
    private Button mNine;
    private Button mZero;
    private Button mSin;
    private Button mCos;
    private Button mTan;
    private Button mPlus;
    private Button mMinus;
    private Button mMul;
    private Button mDiv;
    private Button mClear;
    private Button mSqrt;
    private Button mEqual;
    private EditText mGetInput;
    private TextView mQuery;
    private String mInputString = "";
    private Button mMems;
    private Button mMemr;
    private TextView mMemSave;
    private boolean equalClicked;
    private SharedPreferences sharedpreferences;
    public static final String MyPREFERENCES = "MyPrefs" ;
    public static final String Key = "key";
    private Button mMemc;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mSin = findViewById(R.id.sin);
        mCos = findViewById(R.id.cos);
        mTan = findViewById(R.id.tan);
        mPlus = findViewById(R.id.add);
        mMinus = findViewById(R.id.sub);
        mMul = findViewById(R.id.mul);
        mDiv = findViewById(R.id.div);
        mEqual = findViewById(R.id.equal);
        mSqrt = findViewById(R.id.sqrt);
        mClear = findViewById(R.id.clear);
        mGetInput = findViewById(R.id.numberEditText);
        mQuery = findViewById(R.id.query);
        mMems = findViewById(R.id.mems);
        mMemr = findViewById(R.id.memr);
        mMemSave = findViewById(R.id.memSave);
        sharedpreferences = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        mMemc = findViewById(R.id.memc);

        mGetInput.setShowSoftInputOnFocus(false);
        if(sharedpreferences.getAll().containsKey(Key)){
            mMemSave.setText(sharedpreferences.getString(Key,""));
        }

        mMemc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences.Editor editor = sharedpreferences.edit();
                editor.remove(Key);
                mMemSave.setText("");
                editor.commit();
                equalClicked =false;
            }
        });

        mMems.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //equal();
                SharedPreferences.Editor editor = sharedpreferences.edit();
                editor.putString(Key, String.valueOf(mGetInput.getText()));
                String input = mInputString + " = " + String.valueOf(mGetInput.getText());
                mMemSave.setText(input);
                editor.commit();
                equalClicked =false;
            }
        });

        mMemr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(sharedpreferences.getAll().containsKey(Key)){
                    mGetInput.setText(sharedpreferences.getString(Key,""));
                }else{
                    Toast.makeText(getApplicationContext(),"There is no data which is saved!",Toast.LENGTH_SHORT).show();
                }
                equalClicked =false;
            }
        });

        mClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mInputString = "";
                mGetInput.setText("");
                mQuery.setText(mInputString);
                equalClicked =false;
            }
        });

        mSin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String prev = String.valueOf(mGetInput.getText()).trim();
                if(!prev.isEmpty()) {
                    double rad = Math.toRadians(Double.valueOf(prev));
                    double ans = Math.sin(rad);
                    mInputString += String.valueOf(ans);
                    mQuery.setText(mInputString);
                    mGetInput.setText("");

                }
                equalClicked = false;
            }
        });

        mCos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String prev = String.valueOf(mGetInput.getText()).trim();
                if(!prev.isEmpty()){
                    double rad = Math.toRadians(Double.valueOf(prev));
                    double ans = Math.cos(rad);
                    mInputString += String.valueOf(ans);
                    mQuery.setText(mInputString);
                    mGetInput.setText("");

                }
                equalClicked =false;
            }
        });

        mTan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String prev = String.valueOf(mGetInput.getText()).trim();
                if(!prev.isEmpty()) {
                    double rad = Math.toRadians(Double.valueOf(prev));
                    double ans = Math.tan(rad);
                    mInputString += String.valueOf(ans);
                    mQuery.setText(mInputString);

                    mGetInput.setText("");
                }
                equalClicked = false;
            }
        });


        mSqrt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String prev = String.valueOf(mGetInput.getText()).trim();
                double ans = Math.sqrt(Double.valueOf(prev));
                mInputString += String.valueOf(ans);
                equalClicked =false;
                mQuery.setText(mInputString);
                mGetInput.setText("");
            }
        });


        mEqual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(!equalClicked){
                    equal();
                }
            }
        });

    }


    public void operator(View view){
        Button button = (Button)view;
        String operator = (String)button.getText();
        String prev = String.valueOf(mGetInput.getText()).trim();
        if(!equalClicked){
            mInputString+=prev;
        }
        mInputString += operator;
        mQuery.setText(mInputString);
        mGetInput.setText("");
    }




    public void demo(View view){
        Button button = (Button)view;
        String text = (String) button.getText();
        String prev = String.valueOf(mGetInput.getText()).trim();
        mQuery.setText(mInputString+prev+text);
        equalClicked = false;
        String output = prev + text;
        mGetInput.setText(output);
    }

    public void equal(){
        mInputString += String.valueOf(mGetInput.getText()).trim();
        if(mInputString.trim().length() != 0){
            int length = mInputString.length();
            Toast.makeText(getApplicationContext(), mInputString,Toast.LENGTH_SHORT).show();
            int toCount = length - 1;
            if(mInputString.charAt(toCount) == '+' ||
                    mInputString.charAt(toCount) == '-' ||
                    mInputString.charAt(toCount) == '*' ||
                    mInputString.charAt(toCount) == '/'){
                Toast.makeText(getApplicationContext(), "Invalid input",Toast.LENGTH_SHORT).show();
            }else{

                Expression expression = new ExpressionBuilder(mInputString).build();
                try {

                    double result = expression.evaluate();
                    result = Math.round(result);
                    equalClicked = true;
                    Log.v("MainActivity (result): ", String.valueOf(result));
                    mGetInput.setText(result+"");
                    mQuery.setText(mInputString);

                } catch (ArithmeticException ex) {
                    Toast.makeText(getApplicationContext(), ex.getMessage(),Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

}