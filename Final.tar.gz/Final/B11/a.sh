mysql --host=10.10.15.13 --user=sql1 --password=sql1 test << END_MYSQL
show tables;
drop table if exists studlog;
create table  studlog(id int, name varchar(20), book varchar(20));

describe studlog;

insert into studlog values(1,'John','Hadoop');
insert into studlog values(2,'Peter','Java');

select * from studlog;

END_MYSQL
echo "Done with mysql operations";

echo $SQOOP_HOME
echo "Removing hdfs file if exists "

#hadoop fs -rm -r /usr/pavan/studlog

sqoop import --username sql1 --password sql1 --connect jdbc:mysql://10.10.15.13:3306/test --table studlog --m 1 --target-dir /usr/pavan/studlog/

hadoop fs -ls /usr/local/

echo "Mysql table imported successfully ";

# for exporting file, create a empty table first. I have changed table name here
mysql --host=10.10.15.13 --user=sql1 --password=sql1 test << END_MYSQL

drop table if exists hdfsfiledata;
create table hdfsfiledata (id int, name varchar(20), book varchar(20));

describe hdfsfiledata;

END_MYSQL

sqoop export --connect jdbc:mysql://10.10.15.13:3306/test --table hdfsfiledata --m 1 --export-dir /usr/pavan/studlog/

echo "Export successful";

# Check the table contents

echo "select * from hdfsfiledata;" | mysql --host=10.10.15.13 --user=sql1 --password=sql1 test;

echo "Congratulations. Import Export done successfully";

# Script Starts here ########

# ***************************************** ###############

# To run this script use following commands
