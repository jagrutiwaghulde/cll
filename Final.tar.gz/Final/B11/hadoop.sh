#Hadoop Commands

echo $SQOOP_HOME
echo "Removing hdfs file if exists "
printf "\n\n"
hadoop fs -rm -r /user/vikram2401/studlog
printf "\n\n"

printf "Importing Now::\n\n"
sqoop import --username root --password bigbang123 --connect jdbc:mysql://localhost/test?useSSL=false --table studlog --m 1 --direct
printf "\n\nDone Importing\n\n"
printf "\n\nOutput:\n\n"
hadoop fs -cat /user/vikram2401/studlog/part-m-00000


printf "\n\nExporting Now::\n\n"
sqoop export --username root --password bigbang123 --connect jdbc:mysql://localhost:3306/test?useSSL=false --table hdfsfiledata --m 1 --direct --export-dir /user/vikram2401/studlog/part-m-00000
printf "\n\nDone Exporting\n\n"

