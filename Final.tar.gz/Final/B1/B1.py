import json

with open('ip.json') as my_file:
	data = json.load(my_file)

data=data["matrix"]

def Place(r,c):
	for i in range(8):
		for j in range(8):
			if(data[i][j]==1):
				if(r==i):
					return 0
				elif(c==j):
					return 0
				elif(abs(r-i)==abs(c-j)):
					return 0
	return 1

def Queen(row):
	for column in range(8):
		if(data[row][column] or Place(row,column)):
			data[row][column]=1
			if(row==7):
				return 1
			else:
				if(Queen(row+1)):
					return 1
				else:
					data[row][column]=0
	return 0				

print "INTIAL BOARD:"
for i in range(8):
	print data[i]

if(Queen(0)):
	print "FINAL BOARD:"
	for i in range(8):
		print data[i]
else:
	print "QUEEN's PLACEMENT NOT POSSIBLE"



