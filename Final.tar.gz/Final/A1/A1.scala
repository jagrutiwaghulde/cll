object BinarySearch
{
	def binsearch_norec(nos:Array[Int], srno: Int,r:Int) :Int =
	{
		var low=0
		var high=r
		while(high>=low)
		{
			var mid=(low+high)/2
			if(nos(mid)==srno)
				return mid;
			else if(nos(mid)<srno)
				low=mid+1
			else if(nos(mid) > srno)
				high=mid-1
	
		}
		return -1;
	}	

	def binsearch(nos:Array[Int], srno: Int,l:Int,r:Int) :Int =
	{
		var mid=(l+r)/2
		if(l>r) {return -1;}
		else if(nos(mid)==srno)
			{return mid}
		else if(nos(mid)>srno)
		{
			binsearch(nos,srno,l,mid-1)
		}	
		else
		{ binsearch(nos,srno,mid+1,r) }
	}
	def print_res(posn:Int) 
	{
		if(posn == -1)
		{
			println("Not found")
		}
		else
		{
			println("Found at position "+(posn+1)+" in sorted array")
		}
	}
	def main(args:Array[String])
	{
		println("Enter no of elements in array: ")
		var n:Int=Console.readInt
		var nos= new Array[Int](n)
		println("Now enter array elements: ")
		for(i <- 0 to n-1) {
			nos(i)=Console.readInt
		}
		for(i<- 1 to n-1){
    		  for(j <- (i-1) to 0 by -1){
		        if(nos(j)>nos(j+1)){
		          val temp=nos(j+1)
		          nos(j+1)=nos(j)
		          nos(j)=temp
			        }
      			}
		    }
		
		
		println("Enter number to be searched for: ")
		var srno=Console.readInt
		println("1: Binary Search with Recursion")
		println("")
		var posn:Int=binsearch(nos,srno,0,n-1)
		print_res(posn)
		
		println("2: Binary Search without Recursion")
		println("")
		var posn1:Int=binsearch_norec(nos,srno,n-1)
		print_res(posn1)
	
	}	
}	


